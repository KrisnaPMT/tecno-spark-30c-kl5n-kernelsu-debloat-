#!/system/bin/sh
MODDIR=${0%/*}
. "$MODDIR/lib/common.sh"
check_device || { log "SKIP: not TECNO KL5n"; exit 0; }
[ -e "$MODDIR/paused.flag" ] && { log "PAUSED: no changes"; exit 0; }
# Android PackageManager is ready only after Android boot completes.
n=0
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  n=$((n + 1))
  [ "$n" -ge 120 ] && { log "SKIP: boot timeout"; exit 0; }
  sleep 2
done
sleep 8
[ -e "$MODDIR/paused.flag" ] && exit 0
apply_debloat
