#!/system/bin/sh
MODDIR=${0%/*}
. "$MODDIR/lib/common.sh"
# Undo package disable performed by this module when removed from manager.
restore_debloat
