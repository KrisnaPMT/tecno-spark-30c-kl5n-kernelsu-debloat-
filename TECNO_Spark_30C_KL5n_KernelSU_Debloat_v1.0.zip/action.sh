#!/system/bin/sh
# Tap Action in KernelSU Next Manager to undo or apply again.
MODDIR=${0%/*}
. "$MODDIR/lib/common.sh"
if [ -e "$MODDIR/paused.flag" ]; then
  if ! check_device; then
    echo "Batal: HP bukan KL5n"
    exit 1
  fi
  if [ "$(getprop sys.boot_completed)" != "1" ]; then
    echo "Tunggu sampai HP selesai boot lalu coba lagi."
    exit 1
  fi
  rm -f "$MODDIR/paused.flag"
  echo "Menerapkan daftar debloat..."
  apply_debloat
  echo "Selesai. Lihat log pada debloat.log."
else
  # Pause FIRST so the service script cannot re-disable during action.
  touch "$MODDIR/paused.flag"
  echo "Memulihkan package yang dinonaktifkan modul..."
  restore_debloat
  echo "Pemulihan selesai. Klik Action lagi untuk menerapkan ulang."
fi
