#!/system/bin/sh
# Shared by service.sh, action.sh and uninstall.sh.
log() {
  printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$MODDIR/debloat.log"
}
check_device() {
  p="$(getprop ro.product.model) $(getprop ro.product.device) $(getprop ro.product.vendor.device) $(getprop ro.product.system.model)"
  printf '%s\n' "$p" | tr '[:lower:]' '[:upper:]' | grep -Eq '(^|[^A-Z0-9])KL5N([^A-Z0-9]|$)'
}
known_package() {
  grep -Fxq "$1" "$MODDIR/packages/original-43.txt"
}
protected_package() {
  grep -Fxq "$1" "$MODDIR/packages/protected.txt"
}
apply_debloat() {
  if ! check_device; then
    log "FAIL: device guard"; return 1
  fi
  [ -e "$MODDIR/paused.flag" ] && { log "SKIP: paused"; return 0; }
  if ! pm list packages --user 0 > "$MODDIR/.installed.tmp" 2>/dev/null; then
    log "FAIL: pm list packages inaccessible"; return 1
  fi
  if ! pm list packages --user 0 -d > "$MODDIR/.disabled.tmp" 2>/dev/null; then
    rm -f "$MODDIR/.installed.tmp"
    log "FAIL: pm list disabled packages inaccessible"; return 1
  fi
  : >> "$MODDIR/disabled-by-module.txt"
  while IFS= read -r pkg || [ -n "$pkg" ]; do
    case "$pkg" in ''|\#*) continue ;; esac
    if ! known_package "$pkg"; then log "BLOCK unknown: $pkg"; continue; fi
    if protected_package "$pkg"; then log "BLOCK protected: $pkg"; continue; fi
    if ! grep -Fxq "package:$pkg" "$MODDIR/.installed.tmp"; then
      log "SKIP not installed: $pkg"; continue
    fi
    if grep -Fxq "package:$pkg" "$MODDIR/.disabled.tmp"; then
      log "SKIP already disabled: $pkg"; continue
    fi
    if pm disable-user --user 0 "$pkg" >> "$MODDIR/debloat.log" 2>&1; then
      if ! grep -Fxq "$pkg" "$MODDIR/disabled-by-module.txt"; then
        printf '%s\n' "$pkg" >> "$MODDIR/disabled-by-module.txt"
      fi
      printf 'package:%s\n' "$pkg" >> "$MODDIR/.disabled.tmp"
      log "DISABLED: $pkg"
    else
      log "FAIL disable: $pkg"
    fi
  done < "$MODDIR/packages/selected.txt"
  rm -f "$MODDIR/.installed.tmp" "$MODDIR/.disabled.tmp"
  log "APPLY complete"
}
restore_debloat() {
  [ -f "$MODDIR/disabled-by-module.txt" ] || { log "RESTORE nothing to undo"; return 0; }
  : > "$MODDIR/.restore-left.tmp"
  while IFS= read -r pkg || [ -n "$pkg" ]; do
    [ -n "$pkg" ] || continue
    # Restore only names this module recognizes, never arbitrary commands.
    if ! known_package "$pkg"; then
      printf '%s\n' "$pkg" >> "$MODDIR/.restore-left.tmp"
      log "RESTORE skipped unknown: $pkg"; continue
    fi
    if pm enable --user 0 "$pkg" >> "$MODDIR/debloat.log" 2>&1; then
      log "RESTORED: $pkg"
    else
      printf '%s\n' "$pkg" >> "$MODDIR/.restore-left.tmp"
      log "FAIL restore: $pkg"
    fi
  done < "$MODDIR/disabled-by-module.txt"
  mv -f "$MODDIR/.restore-left.tmp" "$MODDIR/disabled-by-module.txt"
  log "RESTORE complete"
}
