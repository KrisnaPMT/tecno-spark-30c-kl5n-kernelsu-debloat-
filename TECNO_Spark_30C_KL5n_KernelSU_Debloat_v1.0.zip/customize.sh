#!/system/bin/sh
# Executed by KernelSU manager installer (sourced by module installer).
ui_print "*************************************"
ui_print " KL5n Selective Debloat v1.0.0"
ui_print "*************************************"
if [ "${KSU:-}" != "true" ] && [ "${KSU:-}" != "1" ]; then
  abort "Pasang dari KernelSU / KernelSU Next Manager, bukan recovery."
fi
DEVICE_PROPS="$(getprop ro.product.model) $(getprop ro.product.device) $(getprop ro.product.vendor.device) $(getprop ro.product.system.model)"
if ! printf '%s\n' "$DEVICE_PROPS" | tr '[:lower:]' '[:upper:]' | grep -Eq '(^|[^A-Z0-9])KL5N([^A-Z0-9]|$)'; then
  abort "Perangkat bukan KL5n (terbaca: $DEVICE_PROPS). Instalasi dihentikan."
fi
ui_print "Model terdeteksi: $DEVICE_PROPS"
ui_print "10 package default, 23 opsional, 10 dilindungi."
ui_print "Terapkan setelah reboot, tidak menghapus APK /system."
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
