TECNO SPARK 30C KL5n | KernelSU / KernelSU Next Debloat v1.0.0

TUJUAN
Menonaktifkan package yang dipilih dari 43 package unik pada daftar asli user.
Tidak menghapus aplikasi dari /system dan tidak membutuhkan meta-overlayfs.
Khusus KL5n; abort/skip di model lain. Dibuat untuk Android 12-16+,
namun BELUM diuji langsung pada firmware KL5n pengguna.

DAFTAR
- packages/original-43.txt: 43 package unik dari file sumber. Di file asli
  com.transsion.iotservice muncul dua kali.
- packages/selected.txt: 10 package aktif default, 23 package lain
  dikomentari agar opsional, 10 dilindungi dan tidak akan dinonaktifkan.
- packages/protected.txt: daftar blocklist keamanan.

PASANG
1. Buat backup; instal ZIP dari KernelSU Next > Modules > Install from storage.
2. Restart. service.sh akan menunggu boot selesai lalu menjalankan
   'pm disable-user --user 0 ...' untuk package yang aktif di selected.txt.
3. Uji kamera, sidik jari, telepon, SMS, data, Wi-Fi, launcher, file picker,
   pengaturan, Play Store, notifikasi, dan fitur khusus yang biasa dipakai.
4. Cek hasil/log melalui root: /data/adb/modules/tecno_kl5n_selective_debloat/debloat.log

PULIHKAN
- Klik tombol Action pada modul di KernelSU Next. Klik pertama:
  restore semua package yang berhasil dinonaktifkan modul dan pause.
- Klik kedua: lanjutkan dan terapkan paket terpilih lagi.
- Menghapus modul melalui KernelSU menjalankan uninstall.sh untuk mencoba
  memulihkan aplikasi yang tercatat.
- PENTING: mematikan/disable toggle modul saja tidak otomatis mengembalikan
  status package Android. Klik Action untuk pulihkan lebih dulu.
- Jika action/uninstall gagal, secara manual jalankan:
  su -c 'pm enable --user 0 com.debug.loggerui'
  (ganti nama dengan package di disabled-by-module.txt).

UBAH DAFTAR
Dengan root, edit /data/adb/modules/tecno_kl5n_selective_debloat/packages/selected.txt
Hapus tanda # di baris optional yang diinginkan. Jangan ganti nama package.
Buka Action untuk restore dan jalankan sekali lagi untuk apply ulang,
atau restart agar package tambahan diterapkan.
Daftar protected ditolak otomatis. File original-43.txt digunakan untuk
validasi supaya nama liar dari file selected.txt tidak pernah diproses.

BATASAN
Ini perubahan PackageManager yang PERSISTEN, bukan overlayfs murni.
Script uninstall berusaha mengembalikan status tetapi jika proses uninstall
atau sistem gagal, mungkin perlu perintah pm enable manual.
Tidak menjanjikan peningkatan FPS/RAM/baterai atau pemulihan ruang /system.
Jangan menggunakan tombol debloat lain untuk package yang sama jika ingin
backup status sederhana dalam modul ini tetap akurat.

Dibuat dari daftar 'Transsion Package.txt' yang diberikan pengguna.
